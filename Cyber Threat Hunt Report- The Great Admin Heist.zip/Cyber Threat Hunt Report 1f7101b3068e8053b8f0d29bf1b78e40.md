# Cyber Threat Hunt Report

## The Great Admin Heist: Tracking “The Phantom Hackers”

**Analyst:** Daniel Avila

**Tooling:** Microsoft Defender for Endpoint (MDE) + KQL

**Device Investigated: anthony-001**

---

## Scenario Summary

At Acme Corp, privileged IT administrator **Bubba Rockerfeatherman III** guards vast digital assets. A covert APT group, **The Phantom Hackers**, compromised Bubba through social engineering and fileless malware. The attacker’s objective: exfiltrate sensitive data and remain undetected using stealthy persistence mechanisms. The mission was to track the adversary’s movements using Microsoft Defender for Endpoint telemetry, uncover their tactics, and stop the breach.

---

## Summary of Findings

| **Flag** | **Objective** | **Finding** |
| --- | --- | --- |
| **1** | Identify fake AV binary | `BitSentinelCore.exe` |
| **2** | Confirm malware was written to disk | Dropped by legitimate Microsoft binary `csc.exe` |
| **3** | Determine execution method | Manually executed by user `4nth0ny!` via `explorer.exe` |
| **4** | Detect keylogger artifact | `systemreport.txt` accessed via Notepad; `.lnk` shortcut created |
| **5** | Check for registry persistence | Registry key: `HKCU\Software\Microsoft\Windows\CurrentVersion\Run` with value `BitSecSvc` |
| **6** | Identify scheduled task persistence | Task name: `UpdateHealthTelemetry` (runs daily at 14:00) |
| **7** | Understand full process chain for task creation | `BitSentinelCore.exe → cmd.exe → schtasks.exe` |
| **8** | Correlate actions to single initiating event | **Timestamp:** `2025-05-07T02:00:36.794406Z` — file created by `csc.exe` |

---

## Forensic Timeline

| **Time** | **Action** |
| --- | --- |
| May 7, 2025 02:00:36 | `BitSentinelCore.exe` dropped to disk by `csc.exe` |
| May 7, 2025 02:02:14 | Executed manually by user `4nth0ny!` via `explorer.exe` |
| May 7, 2025 02:02:14 | Created folder `ThreatMetrics`, dropped keylogger output `systemreport.txt` |
| May 7, 2025 02:02:14 | Added registry key for persistence: `HKCU\...\Run\BitSecSvc` |
| May 7, 2025 02:02:15–02:03:20 | Created scheduled task `UpdateHealthTelemetry` via `schtasks.exe` |
| May 7, 2025 02:06:51 | `systemreport.txt` opened in Notepad; shortcut `systemreport.lnk` created |

---

## Tactics, Techniques, and Procedures (TTPs)

| **MITRE ATT&CK Technique** | **Description** | **Activity** |
| --- | --- | --- |
| T1127 – Trusted Developer Utilities Proxy Execution | Adversaries abuse trusted developer tools like `csc.exe` (C# compiler) to compile and execute malicious payloads at runtime. | Used to compile C# payload via `csc.exe` |
| **T1204.002** User Execution | An adversary may rely upon a user opening a malicious file in order to gain execution. | User manually ran fake AV `BitSentinelCore.exe` |
| **T1547.001** Registry Run Keys | Adversaries **establish persistence** by **modifying registry keys or startup folder locations** so that **malicious programs automatically run when a user logs in**. | Persistence via `HKCU\...\Run` |
| **T1053.005** Scheduled Task | an attacker creates or modifies Windows scheduled tasks to automatically execute malicious programs at specified times for persistence or privilege escalation. | Daily task created for long-term access |
| **T1056.001** Keylogging | an attacker capturing a user's keystrokes to steal sensitive information such as credentials, messages, or other input data. | Dropped and accessed `systemreport.txt` |

---

## Analyst’s Assessment

The Phantom Hackers utilized fileless malware, social engineering, and native tools like `csc.exe` to evade detection. The fake AV binary `BitSentinelCore.exe` was compiled on the host, executed by the user, and immediately began persistence and surveillance activities. All actions, registry changes, scheduled task creation, and log file output stemmed from the malware’s creation at **`2025-05-07T02:00:36.794406Z`**, providing a single point of correlation for incident response.

---

## Conclusion

The hunt successfully uncovered the full attack path from delivery to persistence. Each malicious behavior was tied to a centralized action, allowing for swift remediation and strengthening Acme Corp’s detection posture. The attacker’s stealth was broken by correlating telemetry across file, process, registry, and user interaction layers.

---

## Tools Used

- **Microsoft Defender for Endpoint**
- **Kusto Query Language (KQL)**
- Key tables: `DeviceProcessEvents`, `DeviceFileEvents`, `DeviceRegistryEvents`
- Investigative pivots from process trees, file creation, registry actions, and scheduled tasks

---

## Recommendations

- Delete `BitSentinelCore.exe` from `C:\ProgramData\`
- Remove registry entry from:
    
    `HKCU\Software\Microsoft\Windows\CurrentVersion\Run\BitSecSvc`
    
- Delete scheduled task:
    
    `UpdateHealthTelemetry` via `schtasks /Delete /TN "UpdateHealthTelemetry"`
    
- Block or tightly monitor execution of developer utilities like `csc.exe` (C# compiler)
- Conduct user awareness training focused on social engineering techniques.
- Educate users on identifying fake security tools, pop-ups, or download prompts

---

## Lessons Learned throughout the Threat Hunting Process

This was my first real-world threat hunt, and while I was nervous going in, I was also eager to gain hands-on experience beyond the structured, guided labs I was used to. I had spent a lot of time studying and earning certifications, so I saw this as a chance to apply my theoretical knowledge in a practical scenario. Throughout the hunt, I became much more comfortable navigating Microsoft Defender for Endpoint’s advanced threat hunting tools and crafting KQL queries. The most challenging part was Flag 8. After spending over five hours stuck, I learned a hard but valuable lesson: attention to detail matters deeply in threat hunting, especially when it comes to timestamp precision. I had the correct event and time but failed to use the exact timestamp format expected, down to the microsecond. That small oversight reinforced how important accuracy is when correlating events across systems. My biggest takeaway is that growth comes through struggle. I’ll continue to practice, focus on sharpening weaker areas, and embrace each hunt as a new opportunity to improve.

---

# Threat Hunting Notes and Findings

## Cyber Threat Hunt Scenario

At Acme Corp, the eccentric yet brilliant IT admin, Bubba Rockerfeatherman III, isn’t just patching servers and resetting passwords — he’s the secret guardian of trillions in digital assets. Hidden deep within encrypted vaults lie private keys, sensitive data, and intellectual gold... all protected by his privileged account.

But the shadows have stirred.
A covert APT group known only as The Phantom Hackers 👤 has set their sights on Bubba. Masters of deception, they weave social engineering, fileless malware, and stealthy persistence into a multi-stage campaign designed to steal it all — without ever being seen.

The breach has already begun.
Using phishing, credential theft, and evasive tactics, the attackers have infiltrated Acme’s network. Bubba doesn’t even know he's compromised.

🧠 Your mission:
Hunt through Microsoft Defender for Endpoint (MDE) telemetry, analyze signals, query using KQL, and follow the breadcrumbs before the keys to Bubba’s empire vanish forever.

Will you stop the heist in time… or will the Phantom Hackers disappear with the crown jewels of cyberspace?

Known Information:
DeviceName: anthony-001

---

## **Flag 1: Identify the Fake Antivirus Program Name**

Objective:
Determine the name of the suspicious or deceptive antivirus program that initiated the security incident.

What to Hunt:
Look for the name of the suspicious file or binary that resembles an antivirus but is responsible for the malicious activity.

Thought:
This step is critical for attribution. Identifying the root artifact allows analysts to formulate a hypothesis and determine the origin of the malicious chain of events.

Hints:

1. Platform we use in our company
2. Program name likely begins with the following letters: A, B, or C
3. Contains

### Timeline and Summary of Events

```
DeviceProcessEvents
| where DeviceName contains "anthony-001"
| where FileName startswith "A" or FileName startswith "B" or FileName startswith "C" or InitiatingProcessFileName startswith "A" or InitiatingProcessFileName startswith "B" or InitiatingProcessFileName startswith "C"
| project Timestamp, FileName, FolderPath, InitiatingProcessFileName
| order by Timestamp asc, FileName desc, InitiatingProcessFileName desc
```

I used the following KQL query to search for file names that start with A, B, or C, as indicated in the hints. While reviewing the logs, I discovered a suspicious program named `BitSentinelCore.exe` .

![image.png](Cyber%20Threat%20Hunt%20Report%201f7101b3068e8053b8f0d29bf1b78e40/image.png)

---

## **Flag 2: Malicious File Written Somewhere**

**Objective:**

Confirm that the fake antivirus binary was written to the disk on the host system.

**What to Hunt:**

Identify the one responsible for dropping the malicious file into the disk.

**Thought:**

This validates the delivery mechanism of the dropper and supports behavioral indicators of compromise, particularly in directories often used by malware.

**Hints:**

1. Legit software

2. Microsoft

3. Three

### Timeline of Events and Summary

```
DeviceFileEvents
| where DeviceName == "anthony-001"
| where FileName == "BitSentinelCore.exe"
| where ActionType == "FileCreated" or ActionType == "FileWritten"
| project Timestamp, ActionType, FileName, FolderPath, InitiatingProcessFileName, InitiatingProcessCommandLine
```

![image.png](Cyber%20Threat%20Hunt%20Report%201f7101b3068e8053b8f0d29bf1b78e40/image%201.png)

I ran the KQL query above and found the following InitiatingProcessFileName, `**csc.exe**` stands for the **C# Compiler** — short for **C# Command-Line Compiler**. It is part of the **.NET Framework SDK** and is a **legitimate Microsoft-signed binary** used to compile C# source code into executable files (`.exe`, etc.).

If `**csc.exe**` wrote `BitSentinelCore.exe` to disk, that strongly suggests: 

### On-the-fly Malware Compilation

- An attacker **delivered C# source code** (possibly via a phishing dropper or PowerShell payload).
- The code was **compiled into a .exe** using `csc.exe` — this is a known **fileless-to-disk execution** technique.

---

## **Flag 3: Execution of the Program**

**Objective:**

Verify whether the dropped malicious file was manually executed by the user or attacker.

**What to Hunt:**

Search for process execution events tied to the suspicious binary.

**Thought:**

Execution of the file marks the start of the malicious payloads being triggered, indicating user interaction or attacker initiation.

**Hint:**

1. Bubba clicked the .exe file himself

### Timeline of Events and Summary

```
DeviceProcessEvents
| where DeviceName == "anthony-001"
| where FileName == "BitSentinelCore.exe"
| summarize by InitiatingProcessFileName
```

This query is used to look for information about the "BitSentinelCore.exe" file  and show which other programs or processes were responsible for starting this file. 

![image.png](Cyber%20Threat%20Hunt%20Report%201f7101b3068e8053b8f0d29bf1b78e40/image%202.png)

 `explorer.exe` was the only result returned which indicates strong evidence of **manual launch**.

```
DeviceProcessEvents
| where DeviceName == "anthony-001"
| where FileName == "BitSentinelCore.exe"
| project Timestamp, InitiatingProcessFileName, AccountName, FolderPath, ProcessCommandLine
| order by Timestamp asc
```

This query shows that the AccountName that executed BitSentinelCore was 4nth0ny! which matches the device name of anthony-001, confirming user interaction. This validates that the attacker relied on **social engineering** to trick the privileged user into running the executable directly.

![image.png](Cyber%20Threat%20Hunt%20Report%201f7101b3068e8053b8f0d29bf1b78e40/image%203.png)

---

## Flag 4 - Keylogger Artifact Written

**Objective:**

Identify whether any artifact was dropped that indicates keylogger behavior.

**What to Hunt:**

Search for any file write events associated with possible keylogging activity.

**Thought:**

This confirms credential harvesting or surveillance behavior linked to the fake antivirus binary.

**Hints:**

1. ."a rather efficient way to completing a complex process"

2. News

```
DeviceProcessEvents
| where DeviceName == "anthony-001"
| where ProcessCommandLine has "systemreport"
| project Timestamp, AccountName, ActionType, FileName, ProcessCommandLine, InitiatingProcessFileName, FolderPath, InitiatingProcessCommandLine
```

![image.png](Cyber%20Threat%20Hunt%20Report%201f7101b3068e8053b8f0d29bf1b78e40/image%204.png)

These two logs correlate as part of a user interaction sequence: the first log shows that `notepad.exe` was used to open `systemreport.txt` from the `ThreatMetrics` folder—suggesting the file contained content of interest, such as keylogger output. The second log, created at the exact same timestamp, shows that a shortcut (`systemreport.lnk`) to that file was generated in the Windows Recent Items folder. This confirms that the file was manually accessed by the user or attacker, validating that `systemreport.txt` is an artifact of post-compromise surveillance behavior.

```
DeviceFileEvents
| where DeviceName == "anthony-001"
| where FileName == "systemreport.lnk"
| project Timestamp, DeviceName, ActionType, FileName, FolderPath, InitiatingProcessFileName
```

![image.png](Cyber%20Threat%20Hunt%20Report%201f7101b3068e8053b8f0d29bf1b78e40/image%205.png)

```
DeviceFileEvents
| where DeviceName == "anthony-001"
| where InitiatingProcessFileName contains "BitSentinelCore.exe"
| where ActionType == "FileCreated"
| project Timestamp, DeviceName, ActionType, FileName, FolderPath, InitiatingProcessFileName, InitiatingProcessCommandLine| order by Timestamp desc
```

![image.png](Cyber%20Threat%20Hunt%20Report%201f7101b3068e8053b8f0d29bf1b78e40/image%206.png)

This log shows that `BitSentinelCore.exe` created the `ThreatMetrics` folder within the user’s AppData\Roaming directory at 2:02:14 AM. This directly correlates with the subsequent opening of `systemreport.txt`—a suspicious text file located within that folder—via Notepad, which also triggered the creation of a `.lnk` shortcut in the Recent Items directory. Together, these events confirm that `BitSentinelCore.exe` dropped an artifact consistent with keylogger behavior, which was later accessed, further validating post-compromise surveillance activity.

---

## **Flag 5 – Registry Persistence Entry**

**Objective:**

Determine if the malware established persistence via the Windows Registry.

**What to Hunt:**

Look for registry modifications that enable the malware to auto-run on startup.

**Thought:**

This flag reveals how the malware achieves persistence across system reboots or logins, helping track long-term infection.

**Hint:**

1. Long answer

### Timeline of Events and Summary:

```
DeviceRegistryEvents
| where DeviceName == "anthony-001"
| where InitiatingProcessFileName == "bitsentinelcore.exe"
| project Timestamp, ActionType, RegistryKey, RegistryValueType, RegistryValueName, RegistryValueData, InitiatingProcessCommandLine, InitiatingProcessFolderPath
```

![image.png](Cyber%20Threat%20Hunt%20Report%201f7101b3068e8053b8f0d29bf1b78e40/image%207.png)

The malware established persistence by modifying the registry key

**`HKEY_CURRENT_USER\...\Software\Microsoft\Windows\CurrentVersion\Run`**,

adding a value named **`BitSecSvc`** with the path **`"C:\ProgramData\BitSentinelCore.exe"`**

This registry entry causes the malware to automatically execute upon user login.

The value name mimics legitimate security software, indicating intentional obfuscation.

The change was made by **`BitSentinelCore.exe`**  at 2**:02:14 PM**, confirming the persistence mechanism.

---

## Flag 6 - Daily Scheduled Task Created

**Objective:**

Identify the value proves that the attacker intents for long-term access

**What to Hunt:**

Identify name of the associated scheduled task.

**Thought:**

Without detecting this task, participants might miss that the system stays infected beyond just running the dropper once.

**Hints:**

1. Three

2. Fitness

### Timeline of Events and Summary:

```
DeviceProcessEvents
| where DeviceName == "anthony-001"
| where FileName =~ "schtasks.exe"
| where ProcessCommandLine has "/create"
| project Timestamp, ActionType, FileName, FolderPath,ProcessCommandLine, AccountName
| order by Timestamp desc
```

![image.png](Cyber%20Threat%20Hunt%20Report%201f7101b3068e8053b8f0d29bf1b78e40/image%208.png)

The attacker created a scheduled task named **`UpdateHealthTelemetry`** using **`schtasks.exe`** .

This task runs **`C:\ProgramData\BitSentinelCore.exe`** daily at **14:00**, ensuring the malware remains persistent even if the user reboots or logs out.

The task name mimics legitimate Windows system functionality, further disguising its malicious intent and supporting the attacker’s goal of long-term access.

---

## Flag 7 – Process Spawn Chain

**Objective:**

Understand the full chain of process relationships that led to task creation.

**What to Hunt:**

Trace the parent process that led to cmd.exe, and subsequently to schtasks.exe.

**Thought:**

Illustrates how the attacker leveraged process relationships to implement persistence, providing insight into the execution flow.

**Format:**

parent -> child -> grandchild

**Hint: (**how the answer should look)

bubba.exe -> newworldorder.exe -> illuminate.exe

### **BitSentinelCore.exe -> cmd.exe -> schtasks.exe**

This process chain illustrates how the attacker established persistence using the **Windows Task Scheduler**. After the fake antivirus binary `BitSentinelCore.exe` was executed, it **spawned `cmd.exe`**, the Windows Command Prompt, as a child process. The attacker then used `cmd.exe` to launch **`schtasks.exe`**, a native utility for creating scheduled tasks. This confirms the attacker’s intent to maintain long-term access beyond a single execution.

---

## Flag 8 – Timestamp Correlation

**Objective:**

Correlate all observed behaviors to a single initiating event

**What to Hunt:**

Compare timestamps from the initial execution to file creation, registry modification, and task scheduling.

**Thought:**

Builds a forensic timeline that strengthens cause-and-effect analysis, confirming that all actions originated from the execution of the fake antivirus program.

### **2025-05-07T02:00:36.794406Z**

At 2**:00:36 AM on May 7, 2025**, the malware payload **`BitSentinelCore.exe`** was created on disk by `csc.exe`, which had been launched via `powershell.exe`.

This creation event is the earliest timestamp in the attack timeline and immediately led to:

- The user execution of `BitSentinelCore.exe` at 7:02:14 PM
- The creation of the `ThreatMetrics` folder and the `systemreport.txt` keylogger log
- The registry persistence entry at `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`
- The scheduled task `UpdateHealthTelemetry` via `schtasks.exe`
    
    Because all malicious behavior follows from this event, **7:00:36 PM marks the true initiating event**, satisfying Flag 8’s timestamp correlation requirement.
    

---

### Answers for Threat Hunt Flags:

Flag 1: BitSentinelCore.exe

Flag 2: csc.exe

Flag 3: BitSentinelCore.exe

Flag 4: systemreport.lnk

Flag 5: HKEY_CURRENT_USER\S-1-5-21-2009930472-1356288797-1940124928-500\SOFTWARE\Microsoft\Windows\CurrentVersion\Run

Flag 6: UpdateHealthTelemetry

Flag 7: BitSentinelCore.exe -> cmd.exe -> schtasks.exe

Flag 8: 2025-05-07T02:00:36.794406Z